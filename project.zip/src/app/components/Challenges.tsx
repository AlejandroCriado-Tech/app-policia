import { Trophy, Star, Target, Zap, Shield, Crown } from "lucide-react";

const medals = [
  { id: 1, name: "Constancia", desc: "Estudia 7 días seguidos", icon: Zap, color: "yellow", achieved: true, date: "Ayer" },
  { id: 2, name: "Experto en Leyes", desc: "Aprobados 10 tests de Derecho Penal", icon: Shield, color: "blue", achieved: true, date: "Hace 1 semana" },
  { id: 3, name: "Constitucionalista", desc: "10/10 en un simulacro de la Constitución", icon: Crown, color: "purple", achieved: false, date: null },
  { id: 4, name: "Cacereño de Pro", desc: "Termina el bloque de normativa local", icon: Target, color: "green", achieved: false, date: null },
];

export function Challenges() {
  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="text-center md:text-left">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Retos y Medallas</h2>
        <p className="text-lg text-gray-500">Supera desafíos y consigue recompensas para mantener la motivación alta</p>
      </div>

      {/* Current Challenge */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-white opacity-10 rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute left-0 bottom-0 w-64 h-64 bg-white opacity-10 rounded-full blur-3xl transform -translate-x-1/2 translate-y-1/2"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="w-32 h-32 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border-4 border-white/30 shadow-[0_0_30px_rgba(255,255,255,0.3)]">
            <Trophy className="w-16 h-16 text-yellow-300 drop-shadow-md" />
          </div>
          <div className="flex-1 text-center md:text-left">
            <h3 className="text-sm font-bold uppercase tracking-widest text-indigo-200 mb-1">Reto Semanal</h3>
            <h4 className="text-3xl font-bold mb-3">Maratón de Tests</h4>
            <p className="text-indigo-100 mb-6 text-lg">Realiza 500 preguntas tipo test esta semana para conseguir un pase directo a una tutoría privada.</p>
            
            <div className="space-y-2 max-w-md mx-auto md:mx-0">
              <div className="flex justify-between text-sm font-medium">
                <span>Progreso: 320 / 500</span>
                <span>64%</span>
              </div>
              <div className="w-full bg-indigo-900/50 rounded-full h-3 backdrop-blur-sm border border-indigo-400/30">
                <div className="bg-gradient-to-r from-yellow-400 to-yellow-300 h-3 rounded-full shadow-[0_0_10px_rgba(250,204,21,0.5)] transition-all duration-1000" style={{ width: '64%' }}></div>
              </div>
            </div>
          </div>
          
          <div className="hidden lg:block w-px h-32 bg-white/20 mx-4"></div>
          
          <div className="text-center bg-white/10 p-6 rounded-xl backdrop-blur-sm border border-white/20 min-w-[200px]">
            <p className="text-indigo-200 text-sm font-medium mb-1">Tiempo restante</p>
            <p className="text-4xl font-bold font-mono tracking-tight">2d 14h</p>
            <button className="mt-4 w-full bg-white text-indigo-700 font-bold py-2 rounded-lg hover:bg-indigo-50 transition-colors shadow-sm">
              Ir a Test
            </button>
          </div>
        </div>
      </div>

      {/* Medals Grid */}
      <div>
        <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
          <Star className="w-6 h-6 text-yellow-500" fill="currentColor" />
          Tus Medallas
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {medals.map(medal => (
            <div 
              key={medal.id} 
              className={`bg-white rounded-2xl border ${medal.achieved ? 'border-gray-200 shadow-md' : 'border-gray-100 border-dashed shadow-sm'} p-6 relative overflow-hidden flex flex-col items-center text-center transition-transform hover:-translate-y-1`}
            >
              {!medal.achieved && (
                <div className="absolute inset-0 bg-gray-50/50 backdrop-blur-[1px] z-10"></div>
              )}
              
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 relative ${medal.achieved ? `bg-${medal.color}-100` : 'bg-gray-100'}`}>
                {medal.achieved && (
                  <div className={`absolute -right-2 -top-2 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm border border-gray-100`}>
                    <Star className="w-4 h-4 text-yellow-500" fill="currentColor" />
                  </div>
                )}
                <medal.icon className={`w-10 h-10 ${medal.achieved ? `text-${medal.color}-500` : 'text-gray-400'}`} />
              </div>
              
              <h4 className={`text-lg font-bold mb-2 ${medal.achieved ? 'text-gray-900' : 'text-gray-500'}`}>{medal.name}</h4>
              <p className="text-sm text-gray-500 mb-4 flex-1">{medal.desc}</p>
              
              {medal.achieved ? (
                <span className="text-xs font-medium text-gray-400 bg-gray-100 px-3 py-1 rounded-full">{medal.date}</span>
              ) : (
                <span className="text-xs font-medium text-gray-400 flex items-center gap-1 z-20">
                  <Target className="w-3 h-3" /> Por conseguir
                </span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Leaderboard */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
          <h3 className="text-xl font-bold text-gray-900">Ranking Mensual (Oposición Cáceres)</h3>
          <span className="text-sm font-medium text-gray-500 bg-white px-3 py-1 rounded-full shadow-sm border border-gray-200">Tu posición: #42</span>
        </div>
        <div className="divide-y divide-gray-100">
          {[
            { pos: 1, name: "María R.", pts: 2450, change: "up" },
            { pos: 2, name: "Javier T.", pts: 2320, change: "down" },
            { pos: 3, name: "Elena C.", pts: 2100, change: "same" },
            { pos: 42, name: "Tú", pts: 850, change: "up", isUser: true },
          ].map((user) => (
            <div key={user.pos} className={`p-4 flex items-center gap-4 ${user.isUser ? 'bg-blue-50/50' : 'hover:bg-gray-50'} transition-colors`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                user.pos === 1 ? 'bg-yellow-100 text-yellow-700' :
                user.pos === 2 ? 'bg-gray-200 text-gray-700' :
                user.pos === 3 ? 'bg-orange-100 text-orange-700' :
                'bg-gray-100 text-gray-600'
              }`}>
                {user.pos}
              </div>
              <div className="flex-1 font-medium text-gray-900 flex items-center gap-2">
                {user.name}
                {user.isUser && <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full uppercase tracking-wider font-bold">Tú</span>}
              </div>
              <div className="text-right">
                <span className="font-bold text-gray-900">{user.pts} <span className="text-gray-400 text-sm font-normal">pts</span></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
